<?php

//DBconexion.php

//$connect = new PDO("mysql:host=localhost;dbname=angularjs", "root", "");
$connect = new PDO("mysql:host=localhost;dbname=dbtransportes", "root", "");

?>
